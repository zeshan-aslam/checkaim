@extends('master.main')
@section('singlecilent')
    <!-- BEGIN PAGE -->
    <div id="main-content">
        <!-- BEGIN PAGE CONTAINER-->
        <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->
            <div class="row-fluid">
                <div class="span12">
                    <!-- BEGIN THEME CUSTOMIZER-->
                    <div id="theme-change" class="hidden-phone">
                        <i class="icon-cogs"></i>
                        <span class="settings">
                            <span class="text">Theme Color:</span>
                            <span class="colors">
                                <span class="color-default" data-style="default"></span>
                                <span class="color-green" data-style="green"></span>
                                <span class="color-gray" data-style="gray"></span>
                                <span class="color-purple" data-style="purple"></span>
                                <span class="color-red" data-style="red"></span>
                            </span>
                        </span>
                    </div>
                    <!-- END THEME CUSTOMIZER-->
                    <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                    <h3 class="page-title">
                        Cilents
                    </h3>
                    <ul class="breadcrumb">
                        {{-- <li>
                      <a href="#">Home</a>
                      <span class="divider">/</span>
                  </li>
                  <li>
                      <a href="#">Metro Lab</a>
                      <span class="divider">/</span>
                  </li> --}}
                        <li class="active">
                            Cilent_View
                        </li>
                        <li class="pull-right search-wrap">
                            <form action="search_result.html" class="hidden-phone">
                                <div class="input-append search-input-area">
                                    <input class="" id="appendedInputButton" type="text">
                                    <button class="btn" type="button"><i class="icon-search"></i> </button>
                                </div>
                            </form>
                        </li>
                    </ul>
                    <!-- END PAGE TITLE & BREADCRUMB-->
                </div>
            </div>
            <div class="row-fluid">
                <div class="span8">
                    <div class="widget black">
                        <div class="widget-title">
                            <h4><i class="icon-reorder"></i> Profile </h4>
                            <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                            </span>
                        </div>
                        <div class="widget-body" style="padding-left: 70px!important;
                        padding-right: 32px!important;">
                            <!-- BEGIN FORM-->
                            <form action="#" class="form-horizontal">
                            <div class="control-group">
                                <label class="control-label">FirstName</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['first_name'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">LastName</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['last_name'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Category</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_category'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Url</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_url'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Fax</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_fax'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Phone Number</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_phone'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Email</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_email'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Address</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_address'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Post Code</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_post_code'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">City</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_city'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">State</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_state'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Country</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_country'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Currency</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_Currency'] }}</span>
                                </div>
                               
                            </div>
                            <div class="control-group">
                                <label class="control-label">Status</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['av_campaign_status'] }}</span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Monthly Fee</label>
                                <div class="controls">
                                    <span class="help-inline">{{ $single_view['monthly_license_fee'] }}</span>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                
                    <!-- END GRID PORTLET-->
                </div>

                <!-- END GRID PORTLET-->
            </div>
        </div>
    </div>
    </div>
@endsection
@section('js')
    <!--script for this page only-->
    <script src="{{ asset('theme/assets/data-tables/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('theme/assets/data-tables/DT_bootstrap.js') }}"></script>
    <script src="{{ asset('theme/js/editable-table.js') }}"></script>
    <script>
        jQuery(document).ready(function() {
            EditableTable.init();
        });
    </script>
@endsection
